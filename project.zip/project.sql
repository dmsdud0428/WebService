-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `award`
--

DROP TABLE IF EXISTS `award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `award` (
  `id` char(9) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `rating` varchar(1) DEFAULT NULL,
  `day` date DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `award`
--

LOCK TABLES `award` WRITE;
/*!40000 ALTER TABLE `award` DISABLE KEYS */;
/*!40000 ALTER TABLE `award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `career`
--

DROP TABLE IF EXISTS `career`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `career` (
  `id` char(9) DEFAULT NULL,
  `kind` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `business` varchar(100) DEFAULT NULL,
  `s_day` date DEFAULT NULL,
  `e_day` date DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career`
--

LOCK TABLES `career` WRITE;
/*!40000 ALTER TABLE `career` DISABLE KEYS */;
/*!40000 ALTER TABLE `career` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etc`
--

DROP TABLE IF EXISTS `etc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `etc` (
  `id` char(9) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `s_day` date DEFAULT NULL,
  `e_day` date DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etc`
--

LOCK TABLES `etc` WRITE;
/*!40000 ALTER TABLE `etc` DISABLE KEYS */;
/*!40000 ALTER TABLE `etc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graduate`
--

DROP TABLE IF EXISTS `graduate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `graduate` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `year` varchar(4) DEFAULT NULL,
  `requirement` varchar(20) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graduate`
--

LOCK TABLES `graduate` WRITE;
/*!40000 ALTER TABLE `graduate` DISABLE KEYS */;
INSERT INTO `graduate` VALUES (1,'2016','총 학점',136),(2,'2016','전공 학점',67),(3,'2016','교양 학점',46),(4,'2016','필수 교양',1),(5,'2016','필수 전공',4),(6,'2016','msc 교양',24),(7,'2016','bsm 교양',18),(8,'2016','전문 교양',3),(9,'2016','설계 학점',12),(10,'2016','전공 학점',60),(11,'2017','총 학점',136),(12,'2017','전공 학점',67),(13,'2017','교양 학점',45),(14,'2017','필수 전공',4),(15,'2017','진성애',6),(16,'2017','언어ㆍ사고',9),(17,'2017','수리ㆍ과학',24),(18,'2017','창의ㆍ융합',6),(19,'2017','bsm 교양',18),(20,'2017','전문 교양',3),(21,'2017','설계 학점',12),(22,'2017','전공 학점',60),(23,'2018','총 학점',136),(24,'2018','전공 학점',67),(25,'2018','교양 학점',51),(26,'2018','필수 전공',4),(27,'2018','진성애',6),(28,'2018','언어ㆍ사고',9),(29,'2018','SW/창의적사고',1),(30,'2018','수리ㆍ과학',18),(31,'2018','BARUN 융합',6),(32,'2018','bsm 교양',18),(33,'2018','전문 교양',3),(34,'2018','설계 학점',12),(35,'2018','전공 학점',60);
/*!40000 ALTER TABLE `graduate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interview`
--

DROP TABLE IF EXISTS `interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `interview` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `id` char(9) DEFAULT NULL,
  `year` char(4) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `spec` varchar(100) DEFAULT NULL,
  `review` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interview`
--

LOCK TABLES `interview` WRITE;
/*!40000 ALTER TABLE `interview` DISABLE KEYS */;
INSERT INTO `interview` VALUES (1,'201611803','2018','삼성','학점 : 4.42 토익 : 900점 ','1)면접관 및 지원자는 몇 명이었나요?\r\nPT면접 - 면접관4 : 지원자1 창의,임원면접 - 면접관3 : 지원자1\r\n\r\n2) 어떤 유형의 면접이 진행되었나요?\r\nPT면접, 창의면접, 임원면접\r\n\r\n3) 각 면접은 어떤 식으로 진행되었나요?\r\nPT면접 - 면접 전 3가지 큰 키워드를 주고 그 중 한 문제를 고른 후 꼬리 문제를 풉니다.(디지털 논리회로 관련 3문제) 창의면접 - 공유 경제 서비스에 대한 내용이었습니다. 책임, 공유, 스마트폰 등 제시어가 주어졌고, 그 제시어를 이용해 공유 경제 서비스에 대한 문제와 솔루션을 제시해보라는 문제였습니다. 임원면접 - 저의 이력서와 자기소개서를 토대로 인성적 역량을 질문 받았습니다.'),(2,'201611803','2017','현대','학점: 4.0 토익: 810점','1) 면접관 및 지원자는 몇 명이었나요?\r\n면접관 두 명에 각각 한 명씩 들어갔습니다. 지원자는 함께 보신 분들은 총 20명이 조금 넘었습니다.\r\n\r\n2) 어떤 유형의 면접이 진행되었나요?\r\n구조화 면접, 실무진 면접\r\n\r\n3) 각 면접은 어떤 식으로 진행되었나요?\r\n구조화 면접으로 정해진 질문 세가지를 통해 꼬리물기식 면접이 진행되었으며 또 다른 면접 30분동안 자소서 기반하여 실무진 면접 진행하였습니다.\r\n\r\n4) 내가 받았던 면접질문&답변을 적어주세요.\r\n만약 영업관리로 근무하며 함께 일하게 될 직원을 정리해야 한다면 어떻게 할것인지?\r\n정량적으로 성과를 뽑아 객관적으로 평가하여 가장 부족한 성과를 낸 직원을 정리할 것이라고 답변하였습니다.\r\n어떤 사람과 문제가 생겼을 때 어떻게 대처할 것인지?\r\n문제가 생겼던 적은 많이 없었지만 문제가 생겼을 떄 가능하면 중간 지점을 찾기 위해 노력할 것이며 상대편을 배려하는 것으로 결론 내릴 것이라고 답변하였습니다.'),(3,'201611803','2018','LG','학점: 3.9 토익: 700점','1) 면접관 및 지원자는 몇 명이었나요?\r\n오전에만 40명 오후까지하면 설비만 100명 안쪽일것 같습니다.\r\n\r\n2) 어떤 유형의 면접이 진행되었나요?\r\nPT 이어서 역량 이어서 영어\r\n\r\n3) 각 면접은 어떤 식으로 진행되었나요?\r\nPT: 사업자료가 20개 주어지고 (표위주 및 단서) 그걸 종합하여 3분간 발표 역량: 인성면접은 없었고 전공과 경험 프로젝트 위주였습니다. 영어: 일반영어면접\r\n\r\n4) 내가 받았던 면접질문&답변을 적어주세요.\r\n영어: 왜 LG에 지원했나요?\r\nLG 는 미래를 가지고 있다고 생각한다. 다양한 포트폴리오를 가지고 있고 이를 바탕으로 성장동력을 가지고 있다.\r\n양극재 설비에 대해서 아는대로 말하시오\r\n답변하지 못했습니다.'),(4,'201611803','2017','한화','학점: 3.5 토익: 700점','1) 면접관 및 지원자는 몇 명이었나요?\r\n면접관 다섯명에 지원자 두 명\r\n\r\n2) 어떤 유형의 면접이 진행되었나요?\r\n실무진 면접으로 인성면접\r\n\r\n3) 각 면접은 어떤 식으로 진행되었나요?\r\n인성면접으로 자소서에 관련된 질문만 하게 되며 저축은행에 관련된 질문 위주로 물어봤습니다. 특이하게 특기에 대한 설명을 요구하였습니다.\r\n\r\n4) 내가 받았던 면접질문&답변을 적어주세요.\r\n 저축은행에서 대외활동을 하였는데 왜 그곳에 취직하지 않았는지?\r\n그때 당시 대학생으로써 방학동안에 잠깐 대외활동으로 한 것이었으며 인턴 제의를 받았지만 학교에 복학해야했기 때문에 취직하지 않았다고 답변하였습니다.\r\n최근에 본 신문에서 은행관련된 광고를 본 적 있는지?\r\n전면 광고에서 신한은행이 빅데이터 관련되어 광고를 한 것을 본적이 있으며 이를 통해 현재 은행권에서 가장 중요한 것이 어떤 것인지 알게됐다고 말씀 드렸습니다.\r\n'),(5,'201611803','2018','skt','학점: 4.3 토익 : 820점','1) 면접관 및 지원자는 몇 명이었나요?\r\n제가 면접보러간 날 지원자는 대략 70~80명 되었던 것 같습니다. 면접관은 총 세분이셨습니다.\r\n\r\n2) 어떤 유형의 면접이 진행되었나요?\r\n인성면접과 전공면접 두 가지 진행됐습니다.\r\n\r\n3) 각 면접은 어떤 식으로 진행되었나요?\r\n전공별로 문제풀고 면접방에 들어가서 문제 푼거 설명드리고 그 자리에서 바로 인성면접 시작했습니다.\r\n\r\n4) 내가 받았던 면접질문&답변을 적어주세요.\r\n자신의 성격의 장단점이 뭔지?\r\n성격의 장점은 꼼꼼함이고 성격의 단점은 부끄럼을 탄다는 것 단점은 극복하고있는 방법도 덧붙였음\r\n살면서 힘들었던 일?\r\n영화관 알바하면서 진상고객 상대한 것\r\n\r\n5) 나의 답변에 따른 면접관의 반응 및 분위기는 어땠나요?\r\n대부분 이해가 가신다는 듯 수긍하시며 끄덕이셨고, 웃는 분위기에서 긴장을 풀어주시려 최대한 노력하셔서 좋앗다.\r\n');
/*!40000 ALTER TABLE `interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `introduction`
--

DROP TABLE IF EXISTS `introduction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `introduction` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `id` char(9) DEFAULT NULL,
  `state` tinyint(1) DEFAULT '0',
  `day` date DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `business` varchar(100) DEFAULT NULL,
  `kind` varchar(10) DEFAULT NULL,
  `question_1` varchar(500) DEFAULT NULL,
  `answer_1` varchar(3000) DEFAULT NULL,
  `question_2` varchar(500) DEFAULT NULL,
  `answer_2` varchar(3000) DEFAULT NULL,
  `question_3` varchar(500) DEFAULT NULL,
  `answer_3` varchar(3000) DEFAULT NULL,
  `question_4` varchar(500) DEFAULT NULL,
  `answer_4` varchar(3000) DEFAULT NULL,
  `question_5` varchar(500) DEFAULT NULL,
  `answer_5` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `introduction`
--

LOCK TABLES `introduction` WRITE;
/*!40000 ALTER TABLE `introduction` DISABLE KEYS */;
INSERT INTO `introduction` VALUES (1,'201611803',0,'2018-12-08','KT','네트워크 엔지니어','신입','오디션에서 무엇을 보여주실 것인지 소개해주십시오.','한국통신학회에서 주최한 추계학술대회에서 제 논문(5G 이동통신을 위한 Massive MIMO 시스템에서의 변형된 가중 그래프 컬러링을 이용한 파일럿 할당 기법)에 대해 발표했던 것과 ETRI에서 국가 R&D 과제(서비스 적응형 동적 네트워크 슬라이싱 표준개발)에 참여해 연구했던 네트워크 슬라이싱, SDN, NFV할당에 대해 보여줄 것입니다','입사지원서만으로 표현하기 힘든, 직무와 관련된 본인의 역량을 설명해주십시오.','통신신호처리 연구실에 들어가 통신에 대한 기본적인 이론에 관한 공부와 Matlab을 이용하여 성능 검증을 하고, 5G 기술 중 Massive MIMO에 관해 이론을 처음으로 제안한 교수님의 논문들과 서적으로 공부하고, 변형된 가중 그래프 컬러링 알고리즘을 개발해 파일럿 할당에 관한 논문으로 한국통신학회에서 주최한 추계학술대회와 학교에서 주최한 논문발표회에서 상을 받았습니다. 그리고 ETRI에서 네트워크 슬라이싱 표준개발에 관한 국가 R&D 과제에 참여해 SDN, NFV할당, 네트워크 슬라이싱, 최적화 이론에 관해 잘 알고 있습니다.','해당 업무를 지원하게 된 동기를 서술하시오.','IT 서비스 산업에 대해서 관심을 가지고 공부하면서 그 가능성 또한 무한하다는 것을 알게 되었습니다. IT 서비스를 제공하는 기업들 중에서 특히 KTds는 KT가 보유한 다양한 사업들과 고객들이 최고의 성과를 낼 수 있도록 IT 시스템 구축 강화에 힘쓰고 있는 기업입니다. 또한 ‘IT 활용능력 봉사’를 통해 지역사회의 소외계층에 관심을 갖는 모습을 보이며 사랑을 나누는 따뜻한 기업임을 알게 되었고, 기술과 윤리 모두 갖춘 회사라는 생각에 더욱 관심을 갖게 되었습니다. 이러한 KT ds의 비전은 신뢰받는 IT 전문 기업이고, 고객의 성장과 혁신을 선도할 수 있는 인재가 꼭 필요하다고 생각합니다. 저의 자질에 다양한 경험, 전공지식을 보태어 동반 성장하며 이러한 역량을 발휘하여 IT 서비스의 가치를 창조하고 싶어 지원하였습니다.','','','',''),(2,'201611803',0,'2018-12-08','KT','C++개발자','신입','해당 직무에 지원하게 된 동기와 입사 후 10년 내에 이루고 싶은 목표에 대해 구체적으로 기술해 주십시오.','IT 서비스 산업에 대해서 관심을 가지고 공부하면서 그 가능성 또한 무한하다는 것을 알게 되었습니다. IT 서비스를 제공하는 기업들 중에서 특히 KTds는 KT가 보유한 다양한 사업들과 고객들이 최고의 성과를 낼 수 있도록 IT 시스템 구축 강화에 힘쓰고 있는 기업입니다. 또한 ‘IT 활용능력 봉사’를 통해 지역사회의 소외계층에 관심을 갖는 모습을 보이며 사랑을 나누는 따뜻한 기업임을 알게 되었고, 기술과 윤리 모두 갖춘 회사라는 생각에 더욱 관심을 갖게 되었습니다. 이러한 KT ds의 비전은 신뢰받는 IT 전문 기업이고, 고객의 성장과 혁신을 선도할 수 있는 인재가 꼭 필요하다고 생각합니다. 저의 자질에 다양한 경험, 전공지식을 보태어 동반 성장하며 이러한 역량을 발휘하여 IT 서비스의 가치를 창조하고 싶어 지원하였습니다.','공동의 목표를 달성하기 위해 타인과 협업했던 경험과 그 과정에서 본인이 수행한 역할, 그리고 해당 경험을 통해 얻은 것은 무엇인지 구체적으로 기술해 주십시오.','안드로이드 프로젝트로 블랙박스 앱(App)을 개발하는 프로젝트를 수행했습니다. 저는 팀장의 역할로서 팀원들의 의견을 종합하여 수행방향을 결정하였습니다. 팀장의 의견을 강요하기보다는 다른 사람의 의견을 참조하여 상황을 객관적으로 보았고, 틀린 의견이 제시되었을 때는 자료를 통해 팀원들을 설득하였습니다. 또한 신입생, 갓 복학한 조원 등을 이끌며 모르는 점을 도와주는 배려를 통해 모두가 함께 프로젝트에 참여할 수 있도록 협력하였습니다. 프로젝트 수행방향은 별도의 ‘블랙박스’기기를 사지 않고, 그 기능을 핸드폰으로 수행할 수 있게 하는 것이 목표였습니다. 스마트폰의 g센서를 이용하여 사고발생 시 감지를 한 후 자동저장기능과 GPS를 이용한 현재 위치 문자 전송 기능들을 구현하는 것이 목표였습니다. 하지만 프로젝트에 쓰이는 JAVA언어와 개발 tool인 ‘이클립스’는 팀원 모두에게 익숙하지 않은 기술들이었습니다. 지금까지 배운 것을 활용하기보다 새로운 기술을 가지고 프로젝트 한다는 것이 부담스럽기는 했지만 배운다는 즐거움으로 팀원들과 함께 다 같이 공부는 자세로 임하였고, 교수님의 도움과 함께 결국에는 기획했던 서비스를 구현해 냈습니다. 팀 단위로 활동하는 IT 전문가가 되기 위해서는 협력과 소통의 자세는 필수입니다. 팀원들과의 계속된 소통과 협력은 팀의 성장과 팀이 목표했던 결과물을 성취하는 꼭 필요한 수단이며 이러한 점을 토대로 KT ds에서 팀 구성원의 한 명으로서 계속된 소통과 협력을 하는 팀원이 될 것입니다.','예상치 못한 문제의 발생으로 계획대로 일이 진행되지 않았을 때, 책임감을 가지고 적극적으로 문제를 해결한 경험과, 그 경험을 통해 얻은 것은 무엇인지 구체적으로 기술해 주십시오.','편입 후 첫 학기에 조별 과제를 하던 중 예상치 못하게 조장을 맡았던 적이 있습니다. 조원들과 투표를 통해 조장을 정한 결과 조장이 되었고 전공지식이 많지 않았던 저는 기대보다 걱정이 앞섰습니다. 그래도 조장으로서 책임감과 의무를 다해야 했기 때문에 가야 할 방향을 정하고 팀을 책임지기 위해서 노력했습니다. 첫 학기라 팀원들보다 부족한 전공지식을 가지고 있었기 때문에 조별 과제를 수행하기 위하여 많은 노력들을 했습니다. IT 동아리에 가입을 신청해 전공과목 공부에 대한 도움을 받았고, 주말과 수업이 끝난 후 늦게 까지 도서관에 남아 공부를 하였습니다. 이렇게 의지를 불태운 결과 팀원들에게 가르쳐 줄 수 있을 정도에 전공지식을 갖게 되었고 이러한 변화된 모습에 팀원들은 더 믿고 따르며 의지하기 시작했습니다. 이러한 많은 노력을 통해서 조장으로서의 책임을 다할 수 있었고 팀원들이 적극적으로 도와주고 협조해준 결과 조별 과제와 발표는 잘 마무리할 수 있었습니다. 저는 이때의 경험을 통해 집중을 통한 성장은 빠르다는 것을 느꼈습니다. 또한 좀 더 전공지식에 대한 관심을 갖게 되었고 노력을 통한 조장으로서의 책임을 끝까지 수행할 수 있었기 때문에 책임감의 무게감에 대해서 느낄 수 있었습니다.','','','',''),(3,'201611803',1,'2018-12-08','IBK 기업은행','정보통신','신입','IBK기업은행을 지원한 이유, 그리고 입행 후 IBK기업은행에서 이루고 싶은 목표(포부)에 대해 설명하여 주십시오.','작년 교내에서 개최한 교내 잡페스티벌에서 금융IT상담부스를 방문한 적이 있습니다. 저는 부스에서 금융IT회사의 현직자로 종사하고 있는 졸업생 선배를 만나게 되었습니다. 상담을 받는 과정에서 금융IT의 비전에 대해 설명을 듣게 되었습니다. 이후, \'휙 계좌 개설\', \'ARS 외화 송금\' 등 금융 및 핀테크 솔루션에 대한 개발 및 기술지원에 있어서 IBK 기업은행의 사업 확장을 확인하였고, 핀테크 시장에서 끊임없이 성장하고 있는 이 기업에서 일하고 싶었습니다.  저는 금융 IT에 대한 개발 경험은 없지만, 컴퓨터공학을 전공한 학생으로써 제가 배운 컴퓨터 언어인 JAVA등을 활용하여 충실하게 프로젝트 경험을 쌓고, 전공 활동 이외에 다양한 대외활동을 통해 사람과의 소통능력을 향상시키기 위해 노력해왔습니다. 저는 이러한 경험을 바탕으로 SW개발뿐만 아니라 총체적인 금융 IT 서비스를 관리하는 종합 은행으로 이끌어 가고 싶습니다.  현재 IBK 기업은행은 7곳의 핀테크 기업과 소프트웨어 기업인 웹캐시에 대한 지분 투자 등 IT금융 시대를 준비하기 위한 투자 사업을 넓혀가고 있기 때문에 그에 따른 인력 보강이 필요하다고 생각합니다. 제가 IBK 기업은행에 입사한다면 미래 수입원인 비대면 채널 서비스의 기술을 성실하게 습득하여 장기적으로 해외 금융 IT 시장에서 최고로 인정받는 회사의 일원이 되도록 노력하겠습니다. ','이 은행원으로서 갖춘 경쟁력(역량)을 한 문장으로 정의하고, 그 이유와 관련된 사례에 대해 설명하여 주십시오.','디지털 행원으로서 저의 경쟁력은 적극성입니다. 그 이유는 저의 부족함을 채우기 위해 적극적으로 노력했기 때문입니다. 이런 노력을 하게 된 계기는 \'이것이 자바다 경진대회\' 에서의 실패 때문입니다. 대학 1학년 때, \'이것이 자바다\' 교재를 활용하여 \'이것이 자바다 경진대회\'에 참가하였고, \'자바FX 기반의 ATM\'을 구현해보는 프로젝트를 진행하였습니다. 계좌 생성 로그인, Main 페이지 및 예금, 송금, 잔액 확인 버튼을 이용해 해당 버튼의 이벤트 실행을 목표로 했습니다. 하지만 DB, JSP 학습이 되어 있지 않았기 때문에 회원 데이터 설계를 토대로 한 서버 프로그램상에서 데이터 모델링 및 DAO, DTO 클래스를 코딩하지 못하였고, 이 영역의 학습을 게을리 했습니다. 결국 로그인 기능을 제외한 ATM 버튼 기능만을 구현한 미완성의 프로젝트로 남았습니다. 이를 계기로 학습하지 못한 기술에 적극적으로 접근하는 가치관을 향상시키기 위해 두 가지 노력을 했습니다. ','귀하가 속한 단체나 조직에서 유연한 사고와 창의성을 발휘하여 변화를 주도하거나 어려운 문제를 해결하였던 경험에 대해 기술하여 주십시오','시도해보지 않은 작업을 기획하고, 개발하는 자세는 디지털 행원에게 있어 새로운 아이디어를 향상시킬 수 있는 기회라고 생각합니다. 최근 미세먼지에 대한 높은 이슈를 계기로 팀원 2명과 함께 졸업 프로젝트 주제로 아두이노, 미세먼지 센서, GPS 센서, 블루투스 모듈을 이용하여 미세먼지 값을 측정하고, 측정한 지역을 구글 맵으로 표시하며 미세먼지 수치 값을 그래프 차트로 나타내는 App을 제작하기로 했습니다.  하지만 교수님께서는 기존 미세먼지 측정소와 차이점이 없다고 평가했습니다. 이후 팀원과의 회의를 통해 아두이노 드론을 제작하여 미세먼지 센서를 부착하는 차별성 있는 방법을 시도했습니다. 전국의 측정소가 부족하여 정확한 정보를 사람들에게 제공하지 못하는 단점을 드론 조종을 통해서 확인하고 싶은 지역의 먼지 값을 얻어내는 것이었습니다. 상용화 측면에서 감점을 받았지만, 고정된 장소에서의 측정 방식을 탈피하고 새로운 관점으로 문제를 접근했다는 교수님의 평가를 받게 되었습니다. 이를 통해 새로운 아이디어를 제시하고 최종 결과물을 구현했다는 점에서 기존의 방식을 고수하지 않는 생각을 찾기 위해 고민해보는 경험을 얻게 되었습니다. 하지만 프로젝트 완성 후, 정부의 드론 제한 구역 지정 및 고도 제한 등 사용자를 고려하지 못한 점이 크게 아쉬웠습니다. 이러한 문제점을 보완하여 사용고객을 항상 생각해보는 사람이 되도록 하는 교훈을 얻었습니다. ','','','',''),(4,'201611803',0,'2018-12-08','삼성','소프트웨어','신입','삼성전자를 지원한 이유와 입사 후 회사에서 이루고 싶은 꿈을 기술하십시오.','영삼성캠퍼스 리포터를 하면서 관심을 갖고 대학원에서 전파공학을 공부하면서 통신의 기초인 OFDM 송수신기, DSP 등을 통해 통신신호처리 분야에 관심을 갖고 삼성전자 네트워크사업부 소프트웨어개발직에 지원하게 되었습니다.  석사과정까지 전파공학을 전공하면서 가장 흥미있었단 것은 석사 졸업논문 프로젝트였습니다. 통신신호처리 분야를 공부하면서 학부 졸업 프로젝트에서 C언어와 매트랩을 이용한 DSP 음성번조를 수행하여 졸업작품 전시회에서 인기작품상을 수상한 경험을 토대로 대학원 석사 진학 후 에 통신신호처리의 기본인 OFDM의 송신기에서 적응신호처리 중 대표적인 기술인 디지털 전치왜곡(Digital Predistortion)을 기반한 LUT(Lookup Table), Polynomial(다항식)을 이용해 응용 연구를 했는데, 매트랩을 이용해 프로젝트를 하면서 어려운 점도 많았지만, 흥미롭게 과정을 즐기면서 프로젝트를 수행했습니다. 밤낮 구별없이 프로젝트르 수행한 결과, 한국통신학회에서 많은 사람들이 제 논문 프로젝트에 관심을 가졌습니다. 자신감을 갖고 소프트웨어분야에 도전하게 되었습니다. 이러한 모든 과정들을 통해 키워온 저의 포기를 모르는 집요함과 도전 마인드는 향후 회사의 중요한 소프트웨어개발을 하는데 도움이 될 것이라 생각합니다. ','본인의 성장과정을 간략히 기술하되 현재의 자신에게 가장 큰 영향을 끼친 사건, 인물 등을 포함하여 기술하시기 바랍니다. ','저는 5살까지 또래 친구들에 비해 언어발달이 늦었습니다. 부모님께서 말씀하시기를 어린아이가 말을 구사하려고 노력하는 모습에 귀여룸을 독차지하게 되었는데 내성적인 성격으로 자라다보니 사람들이 많은 곳에서는 말을 못하고 타인의식 하곤 했습니다. 일부에서는 저를 괴롭힌 저도 있었습니다. 이로 인해, 자신감이 저하되고 자존감이 낮아져서 사람들을 피하면서 점점 혼자만의 시간을 가졌습니다. 중학교 재학 기간에는 수학여행, 수련회 활동도 할 수 없어서 조직생활에 부적응했고, 사람들과의 대화도 하지 않았습니다. 하지만 이런 일에 주눅 들지 않고 전문계 고등학교 입학 후, 혼자가 아닌 사람들을 멀리하지 않고 먼저 대화를 시도하고 이를 통해 오해를 점진적으로 풀어가고 고등학교 수학여행, 수련회 활동 등에 적극적인 참여를 통해 자신감과 자존감을 키워갔고, 학교 생활 땐 인간 관계를 맺기 시작했습니다. 제가 먼저 말을 걸고 시도함으로서 진정한 소통의 소중함을 배웠습니다. \r\n','최근 사회이슈 중 중요하다고 생각되는 한가지를 선택하고 이에 관한 자신의 견해를 기술해 주시기 바랍니다.','2016년 이세돌 선수, 중국 바둑선수 커제가 알파고에 패배를 당해 이른바 `인공지능`이라는 단어가 큰 화두다. 컴퓨터가 인간의 지능적인 행동을 모방할 수 있도록 하는 것을 인공지능이라고 말하고 있습니다. 인공지능은 인간에겐 어려운 일을 도맡아 할 수 있겠지만, 한편으론 일자리를 잃어버리기도 합니다. 인공지능은 이공계 출신 취업준비생이나 ICT(Information Communication Technology) 전공자에겐 일자리가 많겠지만, 비전공자인 인문학 전공자에겐 실업자로 전락하거나 평생 단순노동직에 전념할 가능성이 높아지고, 공무원, 행정고시, 변리사, 공인중개사와 같은 고시에 몰려 경쟁률이 더 상승할 것입니다. 심지어 평생 프리터족으로 전락하게 될 가능성이 높다고 생각합니다. 이로 인해 청년 일자리 및 중장년 일자리는 점점 없어지고 더 이상 인간에게 일자리 중요성이 점점 줄어들어 인공지능 로봇이 많이 등장할 것입니다. ','','','','');
/*!40000 ALTER TABLE `introduction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `language` (
  `id` char(9) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `rating` varchar(1) DEFAULT NULL,
  `score` double DEFAULT NULL,
  `day` date DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license`
--

DROP TABLE IF EXISTS `license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `license` (
  `id` char(9) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `rating` varchar(1) DEFAULT NULL,
  `day` date DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license`
--

LOCK TABLES `license` WRITE;
/*!40000 ALTER TABLE `license` DISABLE KEYS */;
/*!40000 ALTER TABLE `license` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `service` (
  `id` char(9) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `kind` varchar(100) DEFAULT NULL,
  `s_day` date DEFAULT NULL,
  `e_day` date DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `subject` (
  `code` char(9) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `m` tinyint(1) DEFAULT '0',
  `bsm` tinyint(1) DEFAULT '0',
  `engineeringMajor` tinyint(1) DEFAULT '0',
  `engineeringR` tinyint(1) DEFAULT '0',
  `major` tinyint(1) DEFAULT '0',
  `majorNecessary` tinyint(1) DEFAULT '0',
  `necessaryR` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES ('AS044','인간심리의이해',3,0,0,0,1,0,0,0),('AS659','일반확률론',3,0,1,0,0,0,0,0),('AS705','컴퓨터네트워크',3,0,0,1,0,1,0,0),('AS711','수리논리',3,1,1,0,0,0,0,0),('AS775','일반통계학',3,0,1,0,0,0,0,0),('AS794','글쓰기',3,0,0,0,0,0,0,1),('AS916','공학윤리',3,0,0,0,1,0,0,0),('AS928','미분적분학1',3,1,1,0,0,0,0,0),('AS929','미분적분학2',3,1,1,0,0,0,0,0),('AS955','일반물리학및실험Ⅰ',3,1,1,0,0,0,0,0),('AS956','일반물리학및실험Ⅱ',3,1,1,0,0,0,0,0),('AS957','일반화학및실험Ⅰ',3,1,1,0,0,0,0,0),('AS958','일반화학및실험Ⅱ',3,1,1,0,0,0,0,0),('CS343','자료구조론',3,0,0,1,0,1,0,0),('DD013','컴퓨터과학개론',3,1,1,0,0,0,0,0),('DD017','이산수학',3,1,0,1,0,1,0,0),('DD298','컴퓨터과학전공및진로탐색',1,0,0,1,0,1,1,0),('DD703','프로그래밍언어론',3,0,0,1,0,1,0,0),('DD724','운영체제',3,0,0,1,0,1,0,0),('DD726','네트워크프로그래밍',3,0,0,1,0,1,0,0),('DD727','데이터베이스',3,0,0,1,0,1,0,0),('DD746','창의기초설계',3,0,0,0,0,1,1,0),('DD747','수치계산',3,1,0,1,0,1,0,0),('DD748','시스템소프트웨어',3,0,0,1,0,1,0,0),('DD771','계산이론',3,0,0,1,0,1,0,0),('DD801','C프로그래밍',3,0,0,0,0,1,1,0),('DD802','자바프로그래밍1',3,0,0,1,0,1,0,0),('DD803','자료구조설계',3,0,0,1,0,1,0,0),('DD804','자바프로그래밍2',3,0,0,1,0,1,0,0),('DD805','워크플로우관리시스템',3,0,0,1,0,1,0,0),('EF624','컴퓨터구조',3,0,0,1,0,1,0,0),('YA029','창의적문제해결전략',3,0,0,0,1,0,0,0);
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-08  6:42:24
